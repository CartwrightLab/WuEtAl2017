#!/usr/bin/bash

samtools view -bh -o CEU13_NA12878.bam ftp://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/NA12878/high_coverage_alignment/NA12878.mapped.ILLUMINA.bwa.CEU.high_coverage_pcr_free.20130906.bam 21:9411180-9421180
samtools view -bh -o CEU13_NA12892.bam ftp://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/NA12892/high_coverage_alignment/NA12892.mapped.ILLUMINA.bwa.CEU.high_coverage_pcr_free.20130906.bam 21:9411180-9421180
samtools view -bh -o CEU13_NA12891.bam ftp://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/NA12891/high_coverage_alignment/NA12891.mapped.ILLUMINA.bwa.CEU.high_coverage_pcr_free.20130906.bam 21:9411180-9421180

rm *.bai

samtools index CEU13_NA12878.bam
samtools index CEU13_NA12892.bam
samtools index CEU13_NA12891.bam
